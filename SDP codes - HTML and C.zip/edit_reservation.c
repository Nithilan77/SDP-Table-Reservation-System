#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 1024
#define FILE_PATH "reservations.txt"
#define TEMP_FILE "temp.txt"

void get_post_data(char *buffer, int length) {
    fread(buffer, 1, length, stdin);
    buffer[length] = '\0';
}

// Helper to extract key=value from URL-style encoded string
char* get_field(const char *data, const char *key) {
    static char value[256];
    char *start = strstr(data, key);
    if (!start) return NULL;

    start += strlen(key) + 1; // skip key and '='
    char *end = strchr(start, '&');
    if (!end) end = strchr(start, '\0');

    int len = end - start;
    strncpy(value, start, len);
    value[len] = '\0';

    // URL decode: convert '+' to space
    for (int i = 0; i < len; i++) {
        if (value[i] == '+') value[i] = ' ';
    }

    return value;
}

int get_id_from_query() {
    char *query = getenv("QUERY_STRING");
    if (!query) return -1;

    int id = -1;
    sscanf(query, "id=%d", &id);
    return id;
}

int main() {
    printf("Content-Type: application/json\r\n\r\n");

    int content_length = atoi(getenv("CONTENT_LENGTH"));
    if (content_length <= 0) {
        printf("{\"success\": false, \"error\": \"No content received\"}");
        return 0;
    }

    char buffer[MAX];
    get_post_data(buffer, content_length);

    int reservation_ID = get_id_from_query();
    if (reservation_ID < 0) {
        printf("{\"success\": false, \"error\": \"Invalid reservation ID\"}");
        return 0;
    }

    char *name = get_field(buffer, "name");
    char *email = get_field(buffer, "email");
    char *guests = get_field(buffer, "guests");
    char *date = get_field(buffer, "date");
    char *time = get_field(buffer, "time");
    char *status = get_field(buffer, "status");

    FILE *fp = fopen(FILE_PATH, "r");
    FILE *temp = fopen(TEMP_FILE, "w");

    if (!fp || !temp) {
        printf("{\"success\": false, \"error\": \"File error\"}");
        return 0;
    }

    char line[MAX];
    int found = 0;
    int current_id = -1;
    char block[10][MAX];
    int block_index = 0;

    while (fgets(line, sizeof(line), fp)) {
        if (strncmp(line, "---", 3) == 0) {
            // If end of a block
            if (current_id == reservation_ID) {
                // Write updated block
                fprintf(temp, "---\n");
                fprintf(temp, "CONFIRMED - Name: %s\n", name ? name : strstr(block[0], ":") + 2);
                fprintf(temp, "Email: %s\n", email ? email : strstr(block[1], ":") + 2);
                fprintf(temp, "Guests: %s\n", guests ? guests : strstr(block[2], ":") + 2);
                fprintf(temp, "Date: %s\n", date ? date : strstr(block[3], ":") + 2);
                fprintf(temp, "Time: %s\n", time ? time : strstr(block[4], ":") + 2);
                fprintf(temp, "Reservation ID: %d\n", reservation_ID);
                fprintf(temp, "Status: %s\n", status ? status : strstr(block[6], ":") + 2);
                fprintf(temp, "---\n");
                found = 1;
            } else {
                // Write original block
                for (int i = 0; i < block_index; i++) {
                    fputs(block[i], temp);
                }
                fputs(line, temp); // write the separator ---
            }
            block_index = 0;
            current_id = -1;
            continue;
        }

        if (strncmp(line, "Reservation ID:", 15) == 0) {
            sscanf(line, "Reservation ID: %d", &current_id);
        }

        if (block_index < 10) {
            strcpy(block[block_index++], line);
        }
    }

    fclose(fp);
    fclose(temp);

    remove(FILE_PATH);
    rename(TEMP_FILE, FILE_PATH);

    if (found) {
        printf("{\"success\": true}");
    } else {
        printf("{\"success\": false, \"error\": \"Reservation not found\"}");
    }

    return 0;
}
