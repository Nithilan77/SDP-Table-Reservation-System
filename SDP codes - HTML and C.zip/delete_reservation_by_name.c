#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 1024

// Helper: trim newline
void trim_newline(char *str) {
    size_t len = strlen(str);
    if (len && str[len - 1] == '\n') str[len - 1] = '\0';
}

// Decode name from query string
void get_name(char *name) {
    char *query = getenv("QUERY_STRING");
    name[0] = '\0';

    if (query) {
        sscanf(query, "name=%99[^&]", name);
        for (int i = 0; name[i]; i++) {
            if (name[i] == '+') name[i] = ' ';
        }
    }
}

int main() {
    char nameToDelete[100];
    get_name(nameToDelete);

    printf("Content-Type: text/plain\n\n");

    if (strlen(nameToDelete) == 0) {
        printf("No name provided.");
        return 0;
    }

    FILE *fp = fopen("C:\\xampp\\cgi-bin\\reservations.txt", "r");
    if (!fp) {
        printf("Error opening reservations.txt");
        return 0;
    }

    FILE *temp = fopen("C:\\xampp\\cgi-bin\\temp.txt", "w");
    if (!temp) {
        printf("Error creating temp file");
        fclose(fp);
        return 0;
    }

    char line[MAX];
    char block[6][MAX];  // One reservation block = 6 lines
    int deleted = 0;

    while (fgets(block[0], sizeof(block[0]), fp)) {
        if (strncmp(block[0], "---", 3) != 0) continue;

        int fullBlock = 1;
        for (int i = 1; i < 6; i++) {
            if (!fgets(block[i], sizeof(block[i]), fp)) {
                fullBlock = 0;
                break;
            }
        }

        if (!fullBlock) break;

        // Extract name from line[1]
        char *sep = strstr(block[1], " - Name: ");
        if (sep) {
            char extractedName[100];
            strcpy(extractedName, sep + 9);
            trim_newline(extractedName);

            if (strcasecmp(extractedName, nameToDelete) == 0) {
                deleted++;
                continue; // Skip writing this block
            }
        }

        // Write block back if not deleted
        for (int i = 0; i < 6; i++) {
            fputs(block[i], temp);
        }
    }

    fclose(fp);
    fclose(temp);

    remove("C:\\xampp\\cgi-bin\\reservations.txt");
    rename("C:\\xampp\\cgi-bin\\temp.txt", "C:\\xampp\\cgi-bin\\reservations.txt");

    if (deleted > 0)
        printf("Deleted %d reservation(s) for '%s'.", deleted, nameToDelete);
    else
        printf("No reservations found for '%s'.", nameToDelete);

    return 0;
}
